#include <iostream>
using namespace std;
 
int main()
{
    //int a;
   int x ,y;
 
   // Some code
   //cout << "Before try \n";
   try {
      cout << "enter any value \n";
      cin>>x>>y;
      if (y==0)
      {
         throw 0;
      }
      else
         cout << " result of dividion ="<<x/y<<endl;
      
   }
   catch (int x ) {
      cout << "division not possible \n";
   }
 
   //cout << "After catch (Will be executed) \n";
   return 0;
}