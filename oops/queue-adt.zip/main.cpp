// CS20B1085 GUGULOTHU RAVINDAR
// menu driven programm for queue

#include "queueclas"
#include <iostream>
using namespace std;

int main()
{
    queue q1;
    int choice, num, numbers;
    while(1)
    {
        cout<<"\n 1.enQueue \n 2. current numbers \n 3. deQueue \n 4.display \n 5.Exit";
        cout<<"\nEnter your choice:";
        cin>>choice;
        switch(choice)
        {
            case 1:
                cout<<"Enter a number to queue :";
                cin>>num;
                q1.enQueue(num);
                break;
            case 2:
            
                if(num==-1)
                {
                    cout<< "\n queue is full"
                }
                {
                    num++;
                    cout<<" the value to deQueue is are ";
                }
                break;
                case 3:
                cout<<"Enter a number to dequeue :";
                cin>>num;
            
                 break;
            case 4:
            
                if(num==-1)
                {
                  cout<<"\nThe queue is empty\n";  
                }
                else
                {
                    cout<<"\nThe deQueue value is:" << num;
                }
                break;
            case 5:
                exit(1);
            default:
                cout<<"\nWrong choice, try again!\n";
        }
    }
    return 1;
}