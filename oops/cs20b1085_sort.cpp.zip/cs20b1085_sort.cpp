// merge two sorts to produce a combined sorted list 
// CS20B1085 GUGULOTHU RAVINDAR
#include<iostream>
using namespace std;

class node
{  
    
    public: 
	int data; 
	node* next;
	node* sorted;
}*head;
void insertSort(int num, node **head);
node *insertSort(int num, node*head)
{
// insert the data
node *sorted;
  node *newnode = newnode;
  newnode->data = num;
  newnode->next = head;
  head = newnode;
  node *current = head;
  while(current!=NULL){
            
            node *next = current->next;
           // sortedInsert(current);
            current = next;
        }
        head = sorted;
/*}
void sortedInsert(node* newnode)
    {*/
       // node *sorted;
        if (sorted == NULL || sorted->data >= newnode->data) {
            newnode->next = sorted;
            sorted = newnode;
        }
        else {
            node* current = sorted;
            while (current->next != NULL
                   && current->next->data < newnode->data) {
                current = current->next;
            }
            newnode->next = current->next;
            current->next = newnode;
        }
    }


// Delete a node
void deleteSort( int num, node **head);
node *deleteSort(int num,node*head)
{
  node *temp = head; 
  node *prev = head;

  if (temp != NULL && temp->data == num) {
  head = temp->next;
  return head;
  }
  // search the num to be deleted
  while (temp != NULL && temp->data != num) {
  prev = temp;
  temp = temp->next;
  }

  // If the num is not present
  if (temp == NULL)
  return head;

  // Remove the node
  prev->next = temp->next;

 //free(temp);
}
void mergeSort(node **head1,node **head2);
void movenode(node* destRef, node* sourceRef);
node *mergeSort(node*head1,node*head2)
{
  // if ((head == NULL) || (head->next == NULL)) 
      //  return head;
     node text;
    
     node* tail = &text;
    text.next = NULL;
    while (1)
    {
        if (head1 == NULL)
        {
            tail->next = head2;
            break;
        }
        else if (head2 == NULL)
        {
            tail->next = head1;
            break;
        }
        if (head1->data <= head2->data)
            movenode((tail->next), head1);
        else
            movenode((tail->next), head2);
 
        tail = tail->next;
    }
    return(text.next);
}   
 
void movenode(node*destRef, node*sourceRef)
{
     
    node* newnode = sourceRef;
    if(newnode != NULL);
 
    sourceRef = newnode->next;
    newnode->next = destRef;
    destRef = newnode;
}
void printList(node* node)
{
    while (node != NULL) {
        cout << node->data << " ";
        node = node->next;
    }
}
void getdisplay(node **ptr)
{
     node *temp = head;
    cout<<"\n\nList elements are - \n";
   while(ptr != NULL) {
    cout<<"%d --->"<<temp->data;
     temp = temp->next;
      }
}

int main()
{
    
    node *head1=NULL, *head2=NULL;
    int choice, num, Choice;
    while(1)
    {
        cout<<"\n 1. insertSort \n 2. deleteSort \n 3. mergeSort \n 4.display \n 5.Exit";
        cout<<"\nEnter your choice:";
        cin>>choice;
        switch(choice)
        {
            
            case 1:
                {
                 cout<<"enter the number to be inserted";
                 cin>>num;
                 cout<<"which list to be add the num? 1 or 2";
                 cin>>Choice;
                 if(Choice==1)
                    {
                    head1 = insertSort(num,head2);
                    }
                 else
                   {
                     head1 = insertSort(num,head2);
                   }
                }
            
                break;
                case 2:
                {
                    cout<<"enter the number to be deletd";
                    cin>>num;
                     cout<<"which list to be delete the num? 1 or 2";
                     cin>>choice;
                     if(Choice==1)
                    {
                     head1 = deleteSort(num,head1);
                    }
                    else
                    {
                     head2 = deleteSort(num,head2);
                    }
                }
                break;
                case 3:
                {
                  cout<<"mergeSort:\n";
                  printList;
                }
                break;
                case 4:
                {
                     cout<<"\n\nList elements are - \n";
                    getdisplay;
                }
                break;
            case 5:
                exit(1);
            default:
                cout<<"\nWrong choice, try again!\n";
        }
    }

    
    
    return 1;
}