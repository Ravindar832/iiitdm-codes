/*#include<iostream>
#include<vector>
using namespace std;

// template function to perform bubble sort on array, arr
template<typename T>
void BubbleSort(T arr[], int n)
{
	for(int i=0;i<n-1;++i){
		for(int j=0;j<n-i-1;++j){
			if(arr[j]>arr[j+1]){
				T temp = arr[j+1];
				arr[j+1] = arr[j];
				arr[j] = temp;
			}
		}
	}
}

// Template function to print array
template<typename T>
void PrintArray(T arr[], int n)
{
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
    cout << "\n\n";
}

int main()
{

   int arr[1000], choice, n;
   while(1)
     {
        cout<<"\n 1. bubble sort";
        cout<<"\n 2. Exit";
        cout<<"\nEnter your choice:";
        cin>>choice;
        switch(choice)
        {
                case 1:
                {
                  cout<<"enter the size of array\n " ;
                  cin>>n;
                  for(int i=0; i<n; i++){
                  cout<<" enter the elements in array ";
                  cin>>arr[i];
                  }
                  cout << "Array Before Sorting: " << endl;
                  PrintArray(arr, n);

                  BubbleSort(arr, n);

                  cout << "Array After Sorting: " << endl;
                  PrintArray(arr, n);
                }                   
                break;
                case 2:
                exit(1);
            default:
                cout<<"\nWrong choice, try again!\n";
        }
    }
return 0;
}*/ 
 