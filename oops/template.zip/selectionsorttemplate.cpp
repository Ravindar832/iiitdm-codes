#include<iostream>
#include<vector>
using namespace std;

// template function to perform bubble sort on array, arr
template<class T>
void selectionSort(T arr[], int n)
{
    int mVal;
	for(int i=0;i<n-1;++i){
	    mVal = i;
		for(int j=i+1;j<n;++j){
			if(arr[j]<arr[mVal]){
			    mVal = j;
			}
		}
		swap(arr[mVal],arr[i]);
	}
}
template<class T>
void displayArray(T arr[], int n)
{
    cout<<"ascending order \n";
    {
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
    }
    cout << "\n\n";
    cout<<"decending order \n";
    {
    for (int i = n-1; i>=0; --i)
        cout << arr[i] << " ";
    }
    cout << "\n\n";
}
// Template function to print array
template<class T>
void PrintArray(T arr[], int n)
{
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
    cout << "\n\n";
}

int main()
{

   int arr[1000], choice, n;
   int x;
   while(1)
     {
        cout<<"\n 1. get values";
        cout<<"\n 2. sort";
        cout<<"\n 3. display";
        cout<<"\n 4. Exit";
        cout<<"\nEnter your choice:";
        cin>>choice;
         switch(choice)
         {
            int x, y;
             try
             {
                 cout<<"enter the value\n";
                 cin>>y;
                 if(y<=0)
                 {
                    throw y;
                    cout<<" wrong value";
                   // goto x;
                 }
             }
             catch(int x)
             {
                 cout<<" enter the value ";
                 cin>>x;
             }
                  case 1:
                  {
                    cout<<"enter the size of array\n " ;
                  cin>>n;
                  for(int i=0; i<n; i++){
                  cout<<" enter the elements in array ";
                  cin>>arr[i];
                  }
                  cout << "Array Before Sorting: " << endl;
                  PrintArray(arr, n);
                  }
                break;
                case 2:
                {
                   selectionSort(arr,n); 
                }
                break;
                case 3:
                {
                    displayArray(arr,n);
                }
                break;
                case 4:
                exit(1);
            default:
                cout<<"\nWrong choice, try again!\n";
        }
    }
return 0;
} 

 
