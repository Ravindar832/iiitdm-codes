// implement program with Area and Volume class.
// CS20B1085 GUGULOTHU RAVINDAR

#include<iostream>
using namespace std;

class area
{
    //area class for rectangle and circle
    private:
    float length,breadth,radius;
    public:
    //default parametsrs in freind function
    friend float rectangle(float length,float breadth);
    friend float circle(float radius);
};
class volume
{
    //volume class for cuboid and sphere
    private:
    float length,breadth,height,radius;
    public:
    //default parametsrs in freind function
    friend float cuboid(float length,float breadth,float height);
    friend float sphere(float radius);
    // comparison of cuboid and sphere volume
    void comparisonCubiod();
    void comparisonSphere();
};
// inline function for area class
inline float rectangle(float length,float breadth)  // inline function for rectangle
{
    return length*breadth;  // area= length*breadth
}
inline float circle(float radius) //inline function for circle
{
    return 3.14*radius*radius; // area = pi*r^2
}
// inline function for volume class
inline float cuboid(float length,float breadth,float height) //inline function for cuboid
{
    return length*breadth*height; // volume=lbh
}
inline float sphere(float radius)   //inline function for sphere
{
    return 1.333*3.14*radius*radius*radius;  //volume = 4/3*pi*r^3 
}
// inline function to compare two cuboids
inline void volume::comparisonCubiod()
{
    float length2,breadth2,height2,length,breadth,height;
    this->length=length;
    this->breadth=breadth;
    this->height=height;
    cout<<"enter the length of first cuboid\n";
    cin>>this->length;
    cout<<"enter the breadth of first cuboid\n";
    cin>>this->breadth;
    cout<<"enter the height of first cuboid\n";
    cin>>this->height;
    cout<<"enter the length of second cuboid\n";
    cin>>length2;
    cout<<"enter the breadth of second cuboid\n";
    cin>>breadth2;
    cout<<"enter the height of second cuboid\n";
    cin>>height2;
    float firstCuboid = this->length*this->breadth*this->height;
    float secondCuboid = length2*breadth2*height2;
    if(firstCuboid==secondCuboid)
    {
      cout<<"both cuboids have same volume"<<firstCuboid<<"\n";
    }
    else if(firstCuboid>secondCuboid)
    {
      cout<<"volume of firstCuboid("<<firstCuboid<<")has more than secondCuboid("<<secondCuboid<<")\n";  
    }
    else 
    {
      cout<<"volume of firstCuboid("<<firstCuboid<<")has less than secondCuboid("<<secondCuboid<<")\n";  
    }
}
// inline function to compare two spheres
inline void volume::comparisonSphere()
{
    float radius,radius2;
    this->radius=radius;
    cout<<"enter the radius of first sphere\n";
    cin>>this->radius;
    cout<<"enter the radius of second sphere\n";
    cin>>radius2;
    float firstSphere = this->radius*this->radius*this->radius*3.14*1.3333;
    float secondSphere = radius2*radius2*radius2*3.14*1.3333;
    if(firstSphere==secondSphere)
    {
      cout<<"both sphers have same volume"<<firstSphere<<"\n";
    }
    else if(firstSphere>secondSphere)
    {
      cout<<"volume of firstSphere("<<firstSphere<<")has more than secondSphere("<<secondSphere<<")\n";  
    }
    else 
    {
      cout<<"volume of firstSphere("<<firstSphere<<")has less than secondSphere("<<secondSphere<<")\n";  
    }
}
int main()
{
    int choice, num;
    float length,breadth,height,radius;
    while(1)
    {
    cout<<" n.1 area of rectangle\n";
    cout<<" n.2 area of circle\n";
    cout<<" n.3 unit area of rectangle\n";
    cout<<" n.4 unit area of circle\n";
    cout<<" n.5 unit volume of cuboid\n";
    cout<<" n.6 unit volume of sphere\n";
    cout<<" n.7 volume of cuboid\n";
    cout<<" n.8 volume of sphere\n";
    cout<<" n.9 compare volume of two cuboids\n";
    cout<<" n.10 compare volume of two spheres\n";
    cout<<" n.11 exit\n";
    cout<<" enter your choice\n";
    cin>>choice;
    switch(choice)
     {
        case 1:
        {
            cout<<"enter the length of rectangle\n";
            cin>>length;
            cout<<"enter the breadth\n";
            cin>>breadth;
            cout<<"area of rectangle\n" <<rectangle( length, breadth)<<"\n";
        }
        break;
        case 2:
        {
            cout<<"enter the radius of the circle\n";
            cin>>radius;
            cout<<"area of circle\n"<<circle(radius)<<"\n";
        }
        break;
        case 3:
        {
            cout<<"unit area of rectangle\n"<<rectangle(length=1,breadth=1)<<"\n";
        }
        break;
        case 4:
        {
           cout<<"unit area of circle\n"<<circle(radius=1)<<"\n"; 
        }
        break;
        case 5:
        {
            cout<<"unit volume of the cuboid\n"<<cuboid(length=1,breadth=1,height=1)<<"\n";
        }
        break;
        case 6:
        {
            cout<<"unit volume of the sphere\n"<<sphere(radius=1)<<"\n";
        }
        break;
        case 7:
        {
            cout<<"enter the length of cuboid\n";
            cin>>length;
            cout<<"enter the breadth\n";
            cin>>breadth;
            cout<<"enter the height\n";
            cin>>height;
            cout<<"volume of the cuboid\n"<<cuboid(length,breadth,height)<<"\n";
        }
        break;
        case 8:
        {
            cout<<"enter the radius of sphere\n";
            cin>>radius;
            cout<<"volume of the sphere\n"<<sphere(radius)<<"\n";
        }
        break;
        case 9:
        {
            volume v;
          v.comparisonCubiod();
        }
        break;
        case 10:
        {
          volume v;
          v.comparisonSphere();
        }
        break;
        case 11:
        {
          exit(1);
           default:
                cout<<"\nWrong choice, try again!\n";
  
        }
        break;
       
     }
    }
    return 0;
}