#include<iostream>

using namespace std;
int globalid=0;

class apple
{
    protected:
    int appleCost;
    int applestock;
    public:
    
    apple()
    {
       appleCost = 20;
    }
    ~apple()
    {
       applestock = 0;
    }
};
class orange
{
    protected:
    int orangeCost;
    int orangestock;
    public:
    
    orange()
    {
       orangeCost = 15;
    }
    ~orange()
    {
       orangestock = 0;
    } 
};
class strawberry
{
    protected:
    int strawberryCost;
    int strawberrystock;
    public:
    
    strawberry()
    {
       strawberryCost = 25;
    }
    ~strawberry()
    {
       strawberrystock = 0;
    } 
};
class bill: protected orange,protected apple, protected strawberry
{
    private:
          int b,O,S,B,GST;
          int id;
  
    
    public:
    void setDetails()
    {
        cout<<"\napple Cost:";
        cin>>appleCost;
        cout<<"\napple stock:";
        cin>>applestock;
        cout<<"\norange Cost:";
        cin>>orangeCost;
        cout<<"\norange stock:";
        cin>>orangestock;
        cout<<"\nstrawberry stock:";
        cin>>strawberrystock;
        cout<<"\nstrawberry cost:";
        cin>>strawberryCost;
        
    }
    void getDetails()
    {
       cout<<B;
     }
    void setID()
    {
        globalid++;
        id=globalid;
       
        
    }
    void calculateBill()
    {
         
         cout<<"\nnumber of apples bought:";
         cin>>b;
         if(applestock-b>0)
           {
            applestock=applestock-b;
           }
           else
           {
               b=applestock;
               applestock=applestock-b;
               
           }
         
         {
         cout<<"\nnumber of oranges bought:";
         cin>>O;
         orangestock=orangestock-O;
         }
         
         cout<<"\nnumber of Strawberry bought:";
         cin>>S;
         strawberrystock=strawberrystock-S;
         
         B=b*appleCost+O*orangeCost+S*strawberryCost;
         GST=B*18/100;
         B=B+GST;
         cout<<"bill is"<<B<<endl;
    }
};
int main()
{
    bill a[100];
    int i;
int choice;
      while(1)
     {
        cout<<"\n 1. Set Inventory (Apple or Orange or Strawberry)";
        cout<<"\n 2. Display Inventory (Apply or Orange or Strawberry)";
        cout<<"\n 3. Calculate Bill";
        cout<<"\n 4. Exit";
        cout<<"\nEnter your choice:";
        cin>>choice;
        switch(choice)
        {
                case 1:
                {
                 a[0].setDetails();
               break;
            case 2:
             cout<<"enter ID:";
              cin>>i;
                 a[i].getDetails();
               break;
            case 3:
            a[0].setID();
                 a[0].calculateBill(); 
                }                   
                
                case 4:
                exit(1);
            default:
                cout<<"\nWrong choice, try again!\n";
        }
    }
    return 0;
}
