/*#include <iostream>
using namespace std;

class Numbers
{
  // data members (variableS)
  private:
    int Num1, Num2;
    string Name;
    
    
    
  // Member function
  public:
    
    Numbers() // constructor is used for initizing the values
    {
       Num1=0;
       Num2=0;
       Name= "OOPS";
    }
    
    Numbers(int num1, int num2,string name) // parameterized constructor
    {
        Num1=num1;
        Num2=num2;  
        Name=name;
    }
    
    void setNumbers() // member function 1
    {
        
      
    }
    
    void getNumbers()// member function 2
    {
       cout<<Num1<< endl;
      cout<<Num2 <<endl;
       cout<<Name<<endl;
    }
  
};

int main()
{
    Numbers n1; // create an object
    cout<<"Initial value is" << endl;
      
    n1.getNumbers(); // to display value of two numbers
    
    Numbers n2(4,5,"Students"); // calling parameterized constructor
    n2.getNumbers(); // to display value of two numbers
    
    
    return 1;
}*/
