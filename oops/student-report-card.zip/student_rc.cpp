#include"studentclas"
#include<iostream>
using namespace std;
int main()
{  
   int choice;
   while(1)
   {
       cout<<"n1.dispay student 1\n,n2.dispay student 2\n,n3.dispay student 3\n,n4.dispay student 4\n,n5.dispay student 5\n,n6.exit";
       cout<<"\n enter your choice";
       cin>>choice;
       
     switch(choice)
     {
       {
       case 1:
       student s1(60,70,80,50,56,"ravindar","cs85");
       s1.getstudent();
       break;
       }
       {
       case 2:
       student s2(64,75,40,55,54,"arjun","cs80");
       s2.getstudent();
       break;
       }
       {
       case 3:
       student s3(62,73,85,40,46,"bharat","cs75");
       s3.getstudent();
       break;
       }
       {
       case 4:
       student s4(67,76,60,51,59,"lavi","cs70");
       s4.getstudent();
       break;
       }
       {
       case 5:
       student s5(76,56,50,78,69,"rajesh","cs60");
       s5.getstudent();
       break;
       }
       {
           case 6:
           exit(1);
           default:
                cout<<"\nWrong choice, try again!\n";

       }
     }
   }
    return 0;
}