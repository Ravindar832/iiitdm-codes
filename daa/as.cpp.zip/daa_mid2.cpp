// cs20b1085 gugulothu ravindar

#include <iostream>
using namespace std;
  
int partition(int* arr, int low, int high, int* lp);
  
void swap(int* a, int* b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
  
void DualPivotQuickSort(int* arr, int low, int high)
{
    if (low < high) {
        int lp, rp;
        rp = partition(arr, low, high, &lp);
        DualPivotQuickSort(arr, low, lp - 1);
        DualPivotQuickSort(arr, lp + 1, rp - 1);
        DualPivotQuickSort(arr, rp + 1, high);
    }
}
  
int partition(int* arr, int low, int high, int* lp)
{
    if (arr[low] > arr[high])
        swap(&arr[low], &arr[high]);
  
    
    int j = low + 1;
    int g = high - 1, k = low + 1, p = arr[low], q = arr[high];
    while (k <= g) {
  
        
        if (arr[k] < p) {
            swap(&arr[k], &arr[j]);
            j++;
        }
  
        
        else if (arr[k] >= q) {
            while (arr[g] > q && k < g)
                g--;
            swap(&arr[k], &arr[g]);
            g--;
            if (arr[k] < p) {
                swap(&arr[k], &arr[j]);
                j++;
            }
        }
        k++;
    }
    j--;
    g++;
  
   
    swap(&arr[low], &arr[j]);
    swap(&arr[high], &arr[g]);
  
    
    *lp = j; 
    
  
    return g;
}
  
int main()
{
    
    int n,r,x,y;
    cout<<"enter the array size ";
    cin>>n;
    int arr[n];
    for(r=0;r<n;r++)
    {
    cout<<"enter the elements";
    cin>>arr[r];
    }
   cout<<"enter the first pivot";
   cin>>x;
   cout<<"enter the second pivot";
   cin>>y;
    DualPivotQuickSort(arr,x,y);
    cout << "Sorted array: ";
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;
}